package com.coderdream.notebook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotebookApplicationTests {

	@Test
	void contextLoads() {
	}

}
