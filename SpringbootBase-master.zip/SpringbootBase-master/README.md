# SpringbootBase
Study spring boot, base config, security an so on
