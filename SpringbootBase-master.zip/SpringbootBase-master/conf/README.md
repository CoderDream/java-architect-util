该目录下的server.xml及web.xml来源于Local Tomcat的conf目录，它不属于本项目的一部分。

这两个文件用于local tomcat 的HTTPS配置。

server.p12 服务器端证书库
server_trust.p12 服务器信任的客户端证书库