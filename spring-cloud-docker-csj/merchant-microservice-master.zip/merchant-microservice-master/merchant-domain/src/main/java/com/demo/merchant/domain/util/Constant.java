package com.demo.merchant.domain.util;

public class Constant {
    public static final String MERCHANT_CENTER_USER_ID = "MERCHANT_CENTER_USER_ID_";
    public static final String MERCHANT_CENTER_MODEL_ID = "MERCHANT_CENTER_MODEL_ID_";
    public static final String MERCHANT_CENTER_RESOURCE_ID = "MERCHANT_CENTER_RESOURCE_ID_";
    public static final String MERCHANT_CENTER_ROLE_ID = "MERCHANT_CENTER_ROLE_ID_";
    public static final String MERCHANT_CENTER_KIND_ID = "MERCHANT_CENTER_KIND_ID_";
    public static final String MERCHANT_CENTER_MERCHANT_ID = "MERCHANT_CENTER_MERCHANT_ID_";
}