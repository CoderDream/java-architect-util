#项目名称
平台管理微服务
##使用数据库
managedb
##Web服务
ManageWebApplication