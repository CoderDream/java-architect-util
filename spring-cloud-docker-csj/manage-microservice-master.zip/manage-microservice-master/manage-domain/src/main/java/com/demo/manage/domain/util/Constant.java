package com.demo.manage.domain.util;

public class Constant {
    public static final String BOSS_BACKEND_OPERATOR_ID = "BOSS_BACKEND_OPERATOR_ID_";
    public static final String BOSS_BACKEND_PART_ID = "BOSS_BACKEND_PART_ID_";
    public static final String BOSS_BACKEND_MODEL_ID ="BOSS_BACKEND_MODEL_ID_";
    public static final String BOSS_BACKEND_RESOURCE_ID = "BOSS_BACKEND_RESOURCE_ID_";
    public static final String BOSS_BACKEND_DEPARTMENT_ID = "BOSS_BACKEND_DEPARTMENT_ID_";
    public static final String BOSS_BACKEND_KIND_ID ="BOSS_BACKEND_KIND_ID_";

}