package com.roadjava.cache.service;

import com.roadjava.cache.bean.User;

/**
 * @author zhaodaowen
 * @see <a href="http://www.roadjava.com">乐之者java</a>
 */
public interface UserService {
    User getById(Long id);
    User getUser(User queryParam,int[] arr,String str);
}
