<h3 style="color:red;text-align:center">乐之者java: http://www.roadjava.com/ 制作</h3>

<h1 style="color:orange;text-align:center">java缓存专题</h1>

### 一、缓存分类

#### 1.1 单机缓存

* 如ehcache、guava cache

#### 1.2 分布式缓存

* 如redis

### 二、ehcache

#### 2.1 单独使用ehcache

* 官网: https://www.ehcache.org/

* 依赖引入:

  ```xml
  <dependency>
    <groupId>net.sf.ehcache</groupId>
    <artifactId>ehcache</artifactId>
    <version>2.10.6</version>
  </dependency>
  ```

  

#### 2.2 ehcache与spring集成

#### 2.3 ehcache与springboot集成

### 三、guava cache

* 依赖引入:

  ```xml
  <dependency>
    <groupId>com.google.guava</groupId>
    <artifactId>guava</artifactId>
    <version>29.0-jre</version>
  </dependency>
  ```

  

#### 3.1 loadingCache

#### 3.2 自定义CacheManager

#### 3.3 自定义KeyGenerator

### 四、JSR107缓存规范

> jsr : Java Specification Requests

jdbc、lombok/mapstruct（jsr269）、validation

* 依赖

```xml
<!-- JCACHE-->
<dependency>
  <groupId>javax.cache</groupId>
  <artifactId>cache-api</artifactId>
  <version>1.1.1</version>
</dependency>
```

* jcp介绍: https://www.jcp.org/en/jsr/detail?id=107

* 项目地址: https://github.com/jsr107/jsr107spec

* api结构

  ![image-20210917214337770](image-20210917214337770.png)

* 实现如redisson

### 五、spring的缓存抽象

* api结构

  ![image-20210917214500990](image-20210917214500990.png)

### 六、自定义缓存

#### 6.1 剖析缓存应具备哪些功能？

如何设计？ 

* 最大能放多少个,溢出淘汰的机制： LRU、FIFO、LFU
* 过期需要清除
* 内存敏感(不能因为缓存的原因导致业务程序的OOM)
* 线程的安全
* 统计命中率
* 序列化扩展
* .......

#### 6.2 LRU淘汰策略的实现

* 基于LinkedHashMap实现
* 基于LinkedList实现

#### 6.3 内存敏感能力的实现

* 强引用：只要有引用就不会被回收，基本OOM
* 软引用:  gc且堆内存吃紧的时候才会被回收
* 弱引用:  每次gc都会被回收
* 虚引用：随时都有可能被回收





