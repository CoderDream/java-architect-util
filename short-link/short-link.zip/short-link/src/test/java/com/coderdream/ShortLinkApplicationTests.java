package com.coderdream;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShortLinkApplicationTests {

    @Test
    void contextLoads() {
    }

}
