package com.wen.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wen.entity.Book;
import com.wen.entity.News;

public interface NewsMapper extends BaseMapper<News> {

}
