package com.wen.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wen.entity.Book;

public interface BookMapper extends BaseMapper<Book> {

}
