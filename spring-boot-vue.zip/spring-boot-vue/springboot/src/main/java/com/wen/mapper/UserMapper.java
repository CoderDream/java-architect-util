package com.wen.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wen.entity.User;

public interface UserMapper extends BaseMapper<User> {

}
