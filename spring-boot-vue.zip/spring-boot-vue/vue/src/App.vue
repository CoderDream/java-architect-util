<template>
  <div style="background: linear-gradient(90deg,#3cadeb,#9c88ff);">
<!--    根据路由进行访问-->
    <router-view/>

  </div>

</template>

<script>

export default {
  name: "App",
  // components: {
  //   Header,
  //   Aside
  // }
}
</script>