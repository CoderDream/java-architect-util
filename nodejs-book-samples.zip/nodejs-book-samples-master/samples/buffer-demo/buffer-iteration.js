const buf = Buffer.from([1, 2, 3]);

for (const b of buf) {
  console.log(b);
}
// 输出:
//   1
//   2
//   3