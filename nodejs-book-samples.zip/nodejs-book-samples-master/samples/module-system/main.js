var sum = require('./sum.js');
var result = sum.sum(3, 5);

console.log(result);
