var hello = 'Hello World';
console.log(hello);