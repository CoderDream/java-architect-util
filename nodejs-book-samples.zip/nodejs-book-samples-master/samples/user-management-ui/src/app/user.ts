export class User {
    user_id: number;
    username: string;
}