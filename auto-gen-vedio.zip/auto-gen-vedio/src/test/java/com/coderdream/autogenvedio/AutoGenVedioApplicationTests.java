package com.coderdream.autogenvedio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoGenVedioApplicationTests {

    @Test
    void contextLoads() {
    }

}
