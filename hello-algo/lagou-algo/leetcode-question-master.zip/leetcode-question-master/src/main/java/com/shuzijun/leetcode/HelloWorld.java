package com.shuzijun.leetcode;

/**
 * Created with IntelliJ IDEA.
 * User: shuzijun
 * Date: 2018-11-22
 * Time: 20:52
 * To change this template use File | Settings | File Templates.
 */
public class HelloWorld {

    public static void main(String[] args) {
        System.out.println("hello world");
    }
}
