package com.coderdream.passbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MerchantsApplicationTests {

    @Test
    void contextLoads() {
    }

}
