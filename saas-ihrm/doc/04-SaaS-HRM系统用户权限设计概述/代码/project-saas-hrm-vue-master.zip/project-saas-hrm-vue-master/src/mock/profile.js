export default {
    profile:{
        "code" : "10000",
        "success" : true,
        "message" : "登录成功",
        "data" : {
            mobile:"138000138000",
            username:"张三ok",
            company:"江苏传智播客教育科技股份有限公司12345678",
            email:"bipeng@itcast.cn",
        }
    }
}